package com.infinite.Webapp.Repository;

import java.util.List;

import com.infinite.Webapp.Entity.DataClass;

public interface DaoClass {
	public List<DataClass> getAllData();
	public DataClass getData(int id);
	public void addData(DataClass dataclass);
}
