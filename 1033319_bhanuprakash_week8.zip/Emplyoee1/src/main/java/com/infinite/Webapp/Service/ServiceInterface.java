package com.infinite.Webapp.Service;

import java.util.List;

import com.infinite.Webapp.Entity.DataClass;

public interface ServiceInterface {
	public List<DataClass> getAllData();
	public List<DataClass> getData(int id);
	public void addData(DataClass dataclass);
}
